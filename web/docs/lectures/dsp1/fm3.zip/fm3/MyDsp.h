#ifndef faust_teensy_h_
#define faust_teensy_h_

#include "Arduino.h"
#include "AudioStream.h"
#include "Audio.h"

#include "FmThree.h"

class MyDsp : public AudioStream
{
  public:
    MyDsp();
    ~MyDsp();
    
    virtual void update(void);
    void setCFreq(float freq);
    void setM1Freq(float freq);
    void setM1Index(float i);
    void setM2Freq(float freq);
    void setM2Index(float i);
    void setGain(float gain);
    
  private:
    FmThree fmThree;
};

#endif
