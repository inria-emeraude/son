#ifndef FMTHREE_H_INCLUDED
#define FMTHREE_H_INCLUDED

#include "SineTable.h"
#include "Phasor.h"

class FmThree{
public:
  FmThree(int SR);

  void setCFreq(float f);
  void setM1Freq(float f);
  void setM1Index(float i);
  void setM2Freq(float f);
  void setM2Index(float i);
  void setGain(float g);
  float tick();
private:
  SineTable sineTable;
  Phasor cPhasor,m1Phasor,m2Phasor;
  float cFreq,m1Freq,modM1Index,modM2Index,gain;
  int samplingRate;
};

#endif  // FMTHREE_H_INCLUDED
