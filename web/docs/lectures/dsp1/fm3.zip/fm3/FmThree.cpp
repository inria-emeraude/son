#include <cmath>

#include "FmThree.h"

#define SINE_TABLE_SIZE 16384

FmThree::FmThree(int SR) :
sineTable(SINE_TABLE_SIZE),
cPhasor(SR),
m1Phasor(SR),
m2Phasor(SR),
cFreq(440.0),
m1Freq(500.0),
modM1Index(100.0),
modM2Index(100.0),
gain(1.0),
samplingRate(SR){}

void FmThree::setCFreq(float f){
  cFreq = f;
}

void FmThree::setM1Freq(float f){
  m1Freq = f;
}

void FmThree::setM2Freq(float f){
  m2Phasor.setFrequency(f);
}

void FmThree::setM1Index(float i){
  modM1Index = i;
}

void FmThree::setM2Index(float i){
  modM2Index = i;
}

void FmThree::setGain(float g){
  gain = g;
}

float FmThree::tick(){
  int m2Index = m2Phasor.tick()*SINE_TABLE_SIZE;
  float modulator2 = sineTable.tick(m2Index);
  m1Phasor.setFrequency(m1Freq + modulator2*modM2Index);
  int m1Index = m1Phasor.tick()*SINE_TABLE_SIZE;
  float modulator1 = sineTable.tick(m1Index);
  cPhasor.setFrequency(cFreq + modulator1*modM1Index);
  int cIndex = cPhasor.tick()*SINE_TABLE_SIZE;
  return sineTable.tick(cIndex)*gain;
}
